from flask import Flask,render_template,request,jsonify
from deep_translator import GoogleTranslator
app=Flask(__name__)
@app.route('/')
def i(): return render_template('index.html')
@app.route('/translate',methods=['POST'])
def tr():
 d=request.get_json();
 return jsonify({'translation':GoogleTranslator(source=d.get('source','auto'),target=d.get('target','en')).translate(d.get('text',''))})
if __name__=='__main__': app.run(debug=True)