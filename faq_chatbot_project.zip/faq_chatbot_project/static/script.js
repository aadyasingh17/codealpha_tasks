
async function sendMessage(){
 const input=document.getElementById("msg");
 const text=input.value.trim();
 if(!text) return;
 const messages=document.getElementById("messages");
 messages.innerHTML += `<div class="user"><b>You:</b> ${text}</div>`;
 input.value="";
 const res=await fetch("/chat",{
   method:"POST",
   headers:{"Content-Type":"application/json"},
   body:JSON.stringify({message:text})
 });
 const data=await res.json();
 messages.innerHTML += `<div class="bot"><b>Bot:</b> ${data.reply}</div>`;
 messages.scrollTop=messages.scrollHeight;
}
