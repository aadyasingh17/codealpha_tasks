
from flask import Flask, render_template, request, jsonify
import pandas as pd
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

nltk.download("punkt")
nltk.download("stopwords")

app = Flask(__name__)

faq = pd.read_csv("faq.csv")
stop_words = set(stopwords.words("english"))

def preprocess(text):
    words = word_tokenize(str(text).lower())
    words = [w for w in words if w.isalnum()]
    words = [w for w in words if w not in stop_words]
    return " ".join(words)

faq["processed"] = faq["Question"].apply(preprocess)
vectorizer = TfidfVectorizer()
faq_vectors = vectorizer.fit_transform(faq["processed"])

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    msg = request.json.get("message","")
    processed = preprocess(msg)
    user_vec = vectorizer.transform([processed])
    sims = cosine_similarity(user_vec, faq_vectors)[0]
    idx = sims.argmax()
    if sims[idx] < 0.2:
        ans = "Sorry, I couldn't find a relevant answer."
    else:
        ans = faq.iloc[idx]["Answer"]
    return jsonify({"reply": ans})

if __name__ == "__main__":
    app.run(debug=True)
